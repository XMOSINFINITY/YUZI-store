//credit By Limzzzhama 
//no hapus credit ketauan hapus hitam//

module.exports = {
  domain: "https://yuza.pratamahost.web.id/", // Ubah jadi Domain panel Mu !!!
  port: "9001" // Ubah Jadi Port Panel Mu !!!
};